'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Target, Plus, Trash2, ChevronRight, Building2 } from 'lucide-react'
import Link from 'next/link'

interface JobFit {
  id: string
  job_title: string
  company: string
  fit_analysis: any
  created_at: string
}

interface Props {
  jobFits: JobFit[]
}

function fitLevelColor(level: string) {
  if (level === 'Excellent') return { bg: 'rgba(22,163,74,0.08)', color: '#16a34a' }
  if (level === 'Strong') return { bg: 'rgba(99,102,241,0.08)', color: '#6366f1' }
  if (level === 'Moderate') return { bg: 'rgba(217,119,6,0.08)', color: '#d97706' }
  return { bg: 'rgba(220,38,38,0.08)', color: '#dc2626' }
}

function verdictColor(verdict: string) {
  if (verdict === 'Strong Interview') return '#16a34a'
  if (verdict === 'Interview') return '#6366f1'
  if (verdict === 'Borderline') return '#d97706'
  return '#dc2626'
}

export default function JobFitList({ jobFits: initial }: Props) {
  const router = useRouter()
  const [jobFits, setJobFits] = useState(initial)
  const [deleting, setDeleting] = useState<string | null>(null)

  async function handleDelete(id: string) {
    setDeleting(id)
    try {
      await fetch('/api/job-fit', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      })
      setJobFits(prev => prev.filter(j => j.id !== id))
    } finally {
      setDeleting(null)
    }
  }

  return (
    <div style={{ padding: '40px' }}>

      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'flex-start',
        justifyContent: 'space-between', marginBottom: '32px', gap: '16px',
      }}>
        <div>
          <h2 style={{ fontSize: '26px', fontWeight: 600, color: '#09090b', letterSpacing: '-0.5px', marginBottom: '6px' }}>
            My Jobs
          </h2>
          <p style={{ fontSize: '14px', color: '#71717a' }}>
            {jobFits.length === 0
              ? 'No jobs analyzed yet. Start by analyzing a job description.'
              : `${jobFits.length} job${jobFits.length !== 1 ? 's' : ''} analyzed`}
          </p>
        </div>
        <Link href="/job-fit/new" style={{
          display: 'flex', alignItems: 'center', gap: '8px',
          background: '#6366f1', color: 'white', fontSize: '14px',
          fontWeight: 500, padding: '10px 20px', borderRadius: '10px',
          textDecoration: 'none', flexShrink: 0,
        }}>
          <Plus size={15} /> New Analysis
        </Link>
      </div>

      {jobFits.length === 0 ? (
        <div style={{
          background: '#ffffff', border: '1px solid #e4e4e7',
          borderRadius: '16px', padding: '48px', textAlign: 'center',
        }}>
          <Target size={32} strokeWidth={1} style={{ color: '#d4d4d8', marginBottom: '12px' }} />
          <p style={{ fontSize: '16px', fontWeight: 500, color: '#09090b', marginBottom: '8px' }}>
            No jobs analyzed yet
          </p>
          <p style={{ fontSize: '14px', color: '#71717a', marginBottom: '24px' }}>
            Paste a job description and we'll tell you exactly how to position your resume for it.
          </p>
          <Link href="/job-fit/new" style={{
            display: 'inline-flex', alignItems: 'center', gap: '8px',
            background: '#6366f1', color: 'white', fontSize: '14px',
            fontWeight: 500, padding: '10px 20px', borderRadius: '10px',
            textDecoration: 'none',
          }}>
            <Plus size={15} /> Analyze Your First Job
          </Link>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {jobFits.map(job => {
            const analysis = job.fit_analysis
            const level = fitLevelColor(analysis?.fitLevel ?? '')
            const score = analysis?.fitScore ?? 0
            const verdict = analysis?.hiringVerdict ?? ''

            return (
              <div
                key={job.id}
                style={{
                  background: '#ffffff', border: '1px solid #e4e4e7',
                  borderRadius: '16px', overflow: 'hidden',
                }}
              >
                <div style={{
                  padding: '20px 24px', display: 'flex',
                  alignItems: 'center', gap: '16px',
                }}>
                  {/* Score circle */}
                  <div style={{
                    width: '52px', height: '52px', borderRadius: '14px',
                    background: level.bg, display: 'flex', flexDirection: 'column',
                    alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                  }}>
                    <span style={{ fontSize: '17px', fontWeight: 700, color: level.color, lineHeight: 1 }}>
                      {score}
                    </span>
                    <span style={{ fontSize: '9px', color: level.color, fontWeight: 500 }}>/ 100</span>
                  </div>

                  {/* Info */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                      <p style={{ fontSize: '15px', fontWeight: 600, color: '#09090b' }}>
                        {job.job_title}
                      </p>
                      <span style={{
                        fontSize: '11px', padding: '2px 8px', borderRadius: '20px',
                        fontWeight: 500, background: level.bg, color: level.color,
                      }}>
                        {analysis?.fitLevel}
                      </span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <Building2 size={12} style={{ color: '#a1a1aa' }} />
                        <span style={{ fontSize: '13px', color: '#71717a' }}>{job.company}</span>
                      </div>
                      <span style={{ fontSize: '13px', color: verdictColor(verdict), fontWeight: 500 }}>
                        {verdict}
                      </span>
                      <span style={{ fontSize: '12px', color: '#a1a1aa' }}>
                        {new Date(job.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexShrink: 0 }}>
                    <button
                      onClick={() => handleDelete(job.id)}
                      disabled={deleting === job.id}
                      style={{
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        width: '34px', height: '34px', borderRadius: '8px',
                        border: '1px solid #e4e4e7', background: '#ffffff',
                        cursor: 'pointer', color: '#a1a1aa',
                      }}
                    >
                      <Trash2 size={14} />
                    </button>
                    <Link
                      href={`/job-fit/${job.id}`}
                      style={{
                        display: 'flex', alignItems: 'center', gap: '6px',
                        padding: '8px 14px', borderRadius: '8px',
                        background: 'rgba(99,102,241,0.08)', color: '#6366f1',
                        fontSize: '13px', fontWeight: 500, textDecoration: 'none',
                      }}
                    >
                      View <ChevronRight size={13} />
                    </Link>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
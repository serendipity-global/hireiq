import { createClient } from '@/lib/supabase/server'
import { analyzeJobFit } from '@/lib/ai/providers/job-fit'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { jobDescription } = await request.json()

    if (!jobDescription?.trim()) {
      return NextResponse.json({ error: 'Job description is required' }, { status: 400 })
    }

    const { data: resume } = await supabase
      .from('resumes')
      .select('raw_text')
      .eq('user_id', user.id)
      .eq('is_active', true)        
      .single()

    if (!resume?.raw_text) {
      return NextResponse.json({ error: 'No resume found. Please upload your resume first.' }, { status: 400 })
    }

    const analysis = await analyzeJobFit(resume.raw_text, jobDescription)

    // Save to job_fits table
    const { data: jobFit, error } = await supabase
      .from('job_fits')
      .insert({
        user_id: user.id,
        job_title: analysis.jobTitle ?? 'Unknown Position',
        company: analysis.company ?? 'Not specified',
        job_description: jobDescription,
        fit_analysis: analysis,
      })
      .select()
      .single()

    if (error) throw new Error(error.message)

    return NextResponse.json({ success: true, jobFit })

  } catch (error) {
    console.error('Job fit error:', error)
    return NextResponse.json({
      error: error instanceof Error ? error.message : 'Internal server error'
    }, { status: 500 })
  }
}